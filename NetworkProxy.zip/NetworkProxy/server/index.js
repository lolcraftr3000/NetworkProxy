const express = require('express');
const axios = require('axios');
const cors = require('cors');
const { createProxyMiddleware } = require('http-proxy-middleware');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

// Track patterns for analytics/tracking scripts
const trackerPatterns = [
  'google-analytics',
  'googletagmanager',
  'gtm',
  'analytics',
  'tracker',
  'facebook.net',
  'fbevents.js',
  'pixel',
];

// Proxy endpoint
app.get('/api/proxy', async (req, res) => {
  try {
    const targetUrl = req.query.url;
    
    if (!targetUrl) {
      return res.status(400).json({ message: "URL parameter is required" });
    }
    
    // Get proxy settings from query parameters
    const removeScripts = req.query.removeScripts === 'true';
    const removeTrackers = req.query.removeTrackers === 'true';
    const hideReferrer = req.query.hideReferrer === 'true';
    const isGame = req.query.isGame === 'true';
    
    // Validate URL
    try {
      new URL(targetUrl);
    } catch (error) {
      return res.status(400).json({ message: "Invalid URL" });
    }
    
    // Configure request headers
    const headers = {
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
      "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
      "Accept-Language": "en-US,en;q=0.9",
      "Sec-Fetch-Dest": "document",
      "Sec-Fetch-Mode": "navigate",
      "Sec-Fetch-Site": "none",
      "Sec-Fetch-User": "?1",
      "Pragma": "no-cache",
      "Cache-Control": "no-cache"
    };
    
    // Apply hideReferrer if enabled
    if (hideReferrer) {
      headers['Referer'] = '';
    } else {
      // Set a default referer for sites that require it
      const parsedUrl = new URL(targetUrl);
      headers['Referer'] = `${parsedUrl.protocol}//${parsedUrl.host}/`;
    }
    
    // Special handling for YouTube and similar sites
    let timeout = 10000; // Default 10 seconds
    if (targetUrl.includes('youtube.com')) {
      timeout = 15000; // Longer timeout for YouTube
      
      // Add additional headers that YouTube expects
      headers['Cookie'] = 'CONSENT=YES+';
    }
    
    // Special handling for game sites
    if (isGame || 
        targetUrl.includes('game') || 
        targetUrl.includes('play') || 
        targetUrl.includes('arcade') || 
        targetUrl.includes('coolmath')) {
      
      // Adjust headers for games
      headers['Sec-Fetch-Mode'] = 'navigate';
      headers['Sec-Fetch-Site'] = 'cross-site';
      
      // For some game sites that check referrer
      headers['Referer'] = targetUrl;
    }
    
    // Fetch the target URL content
    const response = await axios.get(targetUrl, {
      responseType: "arraybuffer",
      headers,
      maxRedirects: 5,
      timeout: timeout,
      validateStatus: function (status) {
        // Accept all status codes to handle them in our proxy
        return true;
      }
    });
    
    // Get content type and determine how to handle the response
    const contentType = response.headers["content-type"] || "text/html";
    
    // Set the same content type for our response
    res.setHeader("Content-Type", contentType);
    
    // If it's HTML, we might want to rewrite links to go through our proxy
    if (contentType.includes("text/html")) {
      let html = response.data.toString();
      
      // Rewrite URLs in the HTML to go through our proxy
      
      // Process all URLs in href and src attributes
      html = html.replace(/(href|src)=["'](.*?)["']/gi, (match, attr, url) => {
        try {
          // Skip empty URLs
          if (!url || url.trim() === '') {
            return match;
          }
          
          // Skip data: URLs, javascript:, about:, and similar non-http URLs
          if (url.match(/^(data:|javascript:|about:|blob:|#|mailto:|tel:|%)/i)) {
            return match;
          }
          
          // For game sites, preserve certain resource URLs to prevent CORS issues
          if (isGame || 
              targetUrl.includes('game') || 
              targetUrl.includes('play') || 
              targetUrl.includes('arcade') || 
              targetUrl.includes('coolmath')) {
            
            // Leave intact:
            // 1. JavaScript files
            // 2. JSON files 
            // 3. Assets like WASM, Unity files, etc.
            if (url.endsWith('.js') || 
                url.endsWith('.json') || 
                url.endsWith('.wasm') || 
                url.endsWith('.unity3d') || 
                url.includes('unity') ||
                url.includes('asset') || 
                url.includes('bundle')) {
              return match;
            }
          }
          
          // Handle special cases like YouTube URLs
          if (url.includes('youtube.com') || url.includes('ytimg.com') || url.includes('googlevideo.com')) {
            // For YouTube-related resources, use direct URLs to avoid CORS issues
            if (url.includes('/s/player/') || url.includes('.js') || url.includes('.css')) {
              return match;
            }
          }
          
          // Convert relative URLs to absolute using the target URL as base
          let absoluteUrl;
          try {
            absoluteUrl = new URL(url, targetUrl).href;
          } catch (e) {
            // If URL parsing fails, return the original match
            return match;
          }
          
          // Construct the proxy URL with the same settings
          let proxyUrl = `/api/proxy?url=${encodeURIComponent(absoluteUrl)}`;
          if (removeScripts) proxyUrl += "&removeScripts=true";
          if (removeTrackers) proxyUrl += "&removeTrackers=true";
          if (hideReferrer) proxyUrl += "&hideReferrer=true";
          if (isGame) proxyUrl += "&isGame=true";
          
          return `${attr}="${proxyUrl}"`;
        } catch (e) {
          // If any error occurs, return the original match
          console.error("URL rewriting error:", e);
          return match;
        }
      });
      
      // Process CSS urls in style attributes and inline styles
      html = html.replace(/url\(['"]?(.*?)['"]?\)/gi, (match, url) => {
        try {
          // Skip empty URLs
          if (!url || url.trim() === '') {
            return match;
          }
          
          // Skip data: URLs and other non-http protocols
          if (url.match(/^(data:|javascript:|about:|blob:|#|mailto:|tel:|%)/i)) {
            return match;
          }
          
          // Handle YouTube and similar special cases
          if (url.includes('youtube.com') || url.includes('ytimg.com') || 
              url.includes('googlevideo.com') || url.includes('googleusercontent.com')) {
            // For YouTube-related resources, keep original URLs
            return match;
          }
          
          // For game sites, preserve certain resource URLs in CSS to prevent CORS issues
          if (isGame || 
              targetUrl.includes('game') || 
              targetUrl.includes('play') || 
              targetUrl.includes('arcade') || 
              targetUrl.includes('coolmath')) {
            
            // Leave game assets in CSS intact
            if (url.endsWith('.png') || 
                url.endsWith('.jpg') || 
                url.endsWith('.jpeg') || 
                url.endsWith('.gif') || 
                url.endsWith('.svg') || 
                url.endsWith('.webp') ||
                url.includes('sprite') || 
                url.includes('asset') ||
                url.includes('image')) {
              return match;
            }
          }
          
          // Convert relative URLs to absolute
          let absoluteUrl;
          try {
            absoluteUrl = new URL(url, targetUrl).href;
          } catch (e) {
            return match;
          }
          
          // Add settings as query parameters
          let proxyUrl = `/api/proxy?url=${encodeURIComponent(absoluteUrl)}`;
          if (removeScripts) proxyUrl += "&removeScripts=true";
          if (removeTrackers) proxyUrl += "&removeTrackers=true";
          if (hideReferrer) proxyUrl += "&hideReferrer=true";
          if (isGame) proxyUrl += "&isGame=true";
          
          return `url("${proxyUrl}")`;
        } catch (e) {
          console.error("URL rewriting error in CSS:", e);
          return match;
        }
      });
      
      // Remove scripts if requested
      if (removeScripts) {
        html = html.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '');
        html = html.replace(/onclick="[^"]*"/gi, '');
        html = html.replace(/onload="[^"]*"/gi, '');
        html = html.replace(/onerror="[^"]*"/gi, '');
      }
      
      // Remove trackers if requested
      if (removeTrackers && !removeScripts) {
        trackerPatterns.forEach(pattern => {
          const regex = new RegExp(`<script[^>]*${pattern}[^>]*>.*?<\/script>`, 'gi');
          html = html.replace(regex, '');
        });
      }
      
      // Add content security policy to prevent unwanted requests if scripts are allowed
      if (!removeScripts) {
        // For games or YouTube, we need a more permissive CSP to allow all resources
        if (isGame || 
            targetUrl.includes('youtube.com') || 
            targetUrl.includes('game') || 
            targetUrl.includes('play') || 
            targetUrl.includes('arcade') || 
            targetUrl.includes('coolmath')) {
            
          // For game sites, use the most permissive CSP
          res.setHeader('Content-Security-Policy', 
            "upgrade-insecure-requests; " +
            "default-src * 'unsafe-inline' 'unsafe-eval' data: blob:; " +
            "frame-src * data: blob:; " +
            "connect-src * data: blob:; " +
            "img-src * data: blob:; " +
            "media-src * data: blob:; " +
            "font-src * data: blob:; " +
            "script-src * 'unsafe-inline' 'unsafe-eval' data: blob:; " +
            "style-src * 'unsafe-inline';"
          );
          
          // Also add special headers for games
          res.setHeader('Cross-Origin-Embedder-Policy', 'unsafe-none');
          res.setHeader('Cross-Origin-Opener-Policy', 'unsafe-none');
          res.setHeader('Cross-Origin-Resource-Policy', 'cross-origin');
          
        } else {
          res.setHeader('Content-Security-Policy', "upgrade-insecure-requests");
        }
      }
      
      // Ensure cookies aren't accessible to JavaScript
      if (response.headers['set-cookie']) {
        res.setHeader('Set-Cookie', 
          (Array.isArray(response.headers['set-cookie']) ? 
            response.headers['set-cookie'] : [response.headers['set-cookie']])
              .map(cookie => `${cookie}; SameSite=Strict; Secure`)
        );
      }
      
      res.send(html);
    } else {
      // For non-HTML content, pass through as-is
      res.send(response.data);
    }
  } catch (error) {
    console.error("Proxy error:", error);
    
    // Handle specific axios errors
    if (axios.isAxiosError(error)) {
      const status = error.response?.status || 500;
      const message = error.message || "Failed to fetch the requested URL";
      
      return res.status(status).json({ 
        message: `Proxy error: ${message}` 
      });
    }
    
    // Generic error
    res.status(500).json({ 
      message: error instanceof Error 
        ? `Proxy error: ${error.message}` 
        : "Unknown proxy error"
    });
  }
});

// Used for direct proxy forwarding - experimental for games
app.use('/direct-proxy', createProxyMiddleware({
  target: 'https://www.google.com', // This will be overridden
  changeOrigin: true,
  router: function(req) {
    // Get the target URL from the query parameter
    const targetUrl = req.query.url;
    if (!targetUrl) {
      throw new Error('URL parameter is required');
    }
    return targetUrl;
  },
  pathRewrite: function (path, req) {
    // Remove the /direct-proxy prefix from the path
    return path.replace('/direct-proxy', '');
  },
  onProxyReq: function(proxyReq, req, res) {
    // Set headers
    proxyReq.setHeader('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36');
    
    // Add game-specific headers
    if (req.query.isGame === 'true') {
      proxyReq.setHeader('Cross-Origin-Embedder-Policy', 'unsafe-none');
      proxyReq.setHeader('Cross-Origin-Opener-Policy', 'unsafe-none');
    }
  },
  onError: function(err, req, res) {
    res.writeHead(500, {
      'Content-Type': 'application/json'
    });
    res.end(JSON.stringify({ message: `Direct proxy error: ${err.message}` }));
  }
}));

// Serve the Vite app for all other routes (handled by Vite in dev mode)

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running on port ${PORT}`);
});