import { useState, useEffect, useRef } from 'react';
import './App.css';

interface ProxySettings {
  removeScripts: boolean;
  removeTrackers: boolean;
  hideReferrer: boolean;
  tabCloaking: boolean;
  tabTitle: string;
  tabIcon: string;
}

function App() {
  const [currentUrl, setCurrentUrl] = useState<string>('');
  const [inputUrl, setInputUrl] = useState<string>('');
  const [hasContent, setHasContent] = useState<boolean>(false);
  const [history, setHistory] = useState<string[]>([]);
  const [historyIndex, setHistoryIndex] = useState<number>(-1);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [showSettings, setShowSettings] = useState<boolean>(false);
  const [settings, setSettings] = useState<ProxySettings>({
    removeScripts: false,
    removeTrackers: true,
    hideReferrer: true,
    tabCloaking: false,
    tabTitle: 'Google Classroom',
    tabIcon: 'https://ssl.gstatic.com/classroom/ic_product_classroom_32.png',
  });
  
  const iframeRef = useRef<HTMLIFrameElement>(null);
  
  useEffect(() => {
    // Apply tab cloaking if enabled
    if (settings.tabCloaking) {
      document.title = settings.tabTitle;
      const existingIcon = document.querySelector('link[rel="icon"]');
      if (existingIcon) {
        (existingIcon as HTMLLinkElement).href = settings.tabIcon;
      } else {
        const icon = document.createElement('link');
        icon.rel = 'icon';
        icon.href = settings.tabIcon;
        document.head.appendChild(icon);
      }
    } else {
      document.title = 'WebProxy';
      const existingIcon = document.querySelector('link[rel="icon"]');
      if (existingIcon) {
        (existingIcon as HTMLLinkElement).href = '/favicon.ico';
      }
    }
  }, [settings.tabCloaking, settings.tabTitle, settings.tabIcon]);

  const validateAndFormatUrl = (url: string): string => {
    if (!url) return '';
    
    // Add protocol if missing
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      url = 'https://' + url;
    }
    
    try {
      new URL(url); // This will throw if URL is invalid
      return url;
    } catch (error) {
      setErrorMessage('Invalid URL. Please enter a valid URL.');
      return '';
    }
  };

  const handleUrlSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const formattedUrl = validateAndFormatUrl(inputUrl);
    if (formattedUrl) {
      setErrorMessage(null);
      setCurrentUrl(formattedUrl);
      
      // Add to history if it's a new URL
      if (formattedUrl !== history[historyIndex]) {
        const newHistory = history.slice(0, historyIndex + 1);
        newHistory.push(formattedUrl);
        setHistory(newHistory);
        setHistoryIndex(newHistory.length - 1);
      }
      
      setHasContent(true);
    }
  };

  const handleGoBack = () => {
    if (historyIndex > 0) {
      setHistoryIndex(historyIndex - 1);
      setCurrentUrl(history[historyIndex - 1]);
      setInputUrl(history[historyIndex - 1]);
    }
  };

  const handleGoForward = () => {
    if (historyIndex < history.length - 1) {
      setHistoryIndex(historyIndex + 1);
      setCurrentUrl(history[historyIndex + 1]);
      setInputUrl(history[historyIndex + 1]);
    }
  };

  const handleRefresh = () => {
    if (iframeRef.current) {
      const src = iframeRef.current.src;
      iframeRef.current.src = 'about:blank';
      setTimeout(() => {
        if (iframeRef.current) {
          iframeRef.current.src = src;
        }
      }, 100);
    }
  };

  const handleSettingsChange = (key: keyof ProxySettings, value: any) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  return (
    <div className="flex flex-col h-screen bg-gray-100">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-2 sm:px-4 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex flex-1">
              <div className="flex-shrink-0 flex items-center">
                <h1 className="text-xl font-bold text-gray-900">WebProxy</h1>
              </div>
              <div className="ml-6 flex flex-1 items-center">
                <nav className="flex space-x-2">
                  <button 
                    onClick={handleGoBack} 
                    disabled={historyIndex <= 0}
                    className="px-2 py-1 rounded-md text-gray-500 hover:text-gray-700 disabled:text-gray-300 disabled:cursor-not-allowed"
                  >
                    ←
                  </button>
                  <button 
                    onClick={handleGoForward} 
                    disabled={historyIndex >= history.length - 1}
                    className="px-2 py-1 rounded-md text-gray-500 hover:text-gray-700 disabled:text-gray-300 disabled:cursor-not-allowed"
                  >
                    →
                  </button>
                  <button 
                    onClick={handleRefresh}
                    disabled={!hasContent}
                    className="px-2 py-1 rounded-md text-gray-500 hover:text-gray-700 disabled:text-gray-300 disabled:cursor-not-allowed"
                  >
                    ↻
                  </button>
                </nav>
                <form onSubmit={handleUrlSubmit} className="flex-1 ml-4">
                  <div className="relative rounded-md shadow-sm">
                    <input
                      type="text"
                      value={inputUrl}
                      onChange={(e) => setInputUrl(e.target.value)}
                      className="block w-full pr-10 sm:text-sm border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 py-2 px-3"
                      placeholder="Enter URL (e.g. example.com)"
                    />
                  </div>
                </form>
              </div>
            </div>
            <div className="flex items-center">
              <button
                onClick={() => setShowSettings(!showSettings)}
                className="p-2 rounded-md text-gray-500 hover:text-gray-700"
              >
                ⚙️
              </button>
            </div>
          </div>
        </div>
      </header>

      {errorMessage && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-2 m-2 rounded">
          {errorMessage}
        </div>
      )}

      {showSettings && (
        <div className="bg-white shadow-md p-4 m-2 rounded-lg">
          <h2 className="text-lg font-medium mb-3">Settings</h2>
          <div className="flex flex-col gap-3">
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={settings.removeScripts}
                onChange={(e) => handleSettingsChange('removeScripts', e.target.checked)}
                className="rounded"
              />
              Remove scripts (blocks JavaScript, may break functionality)
            </label>
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={settings.removeTrackers}
                onChange={(e) => handleSettingsChange('removeTrackers', e.target.checked)}
                className="rounded"
              />
              Remove trackers
            </label>
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={settings.hideReferrer}
                onChange={(e) => handleSettingsChange('hideReferrer', e.target.checked)}
                className="rounded"
              />
              Hide referrer
            </label>
            <hr />
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={settings.tabCloaking}
                onChange={(e) => handleSettingsChange('tabCloaking', e.target.checked)}
                className="rounded"
              />
              Enable tab cloaking
            </label>
            {settings.tabCloaking && (
              <div className="flex flex-col gap-2 ml-6">
                <label className="flex flex-col gap-1">
                  <span>Tab Title:</span>
                  <input
                    type="text"
                    value={settings.tabTitle}
                    onChange={(e) => handleSettingsChange('tabTitle', e.target.value)}
                    className="border rounded px-2 py-1"
                  />
                </label>
                <label className="flex flex-col gap-1">
                  <span>Tab Icon URL:</span>
                  <input
                    type="text"
                    value={settings.tabIcon}
                    onChange={(e) => handleSettingsChange('tabIcon', e.target.value)}
                    className="border rounded px-2 py-1"
                  />
                </label>
              </div>
            )}
          </div>
        </div>
      )}

      <main className="flex-1 relative overflow-hidden">
        {hasContent ? (
          <iframe 
            ref={iframeRef}
            src={`/api/proxy?url=${encodeURIComponent(currentUrl)}${
              // Automatically detect game sites and disable script removal
              (currentUrl.includes('game') || 
               currentUrl.includes('play') || 
               currentUrl.includes('arcade') || 
               currentUrl.includes('poki') ||
               currentUrl.includes('coolmath'))
                ? '&isGame=true' 
                : `${settings.removeScripts ? '&removeScripts=true' : ''}${settings.removeTrackers ? '&removeTrackers=true' : ''}${settings.hideReferrer ? '&hideReferrer=true' : ''}`
            }`}
            className="w-full h-full border-0"
            title="Proxied Content"
            sandbox="allow-forms allow-scripts allow-same-origin allow-popups allow-modals allow-presentation allow-downloads"
            allow="autoplay; fullscreen; picture-in-picture; encrypted-media; accelerometer; gyroscope; camera; microphone; geolocation"
          />
        ) : (
          <div className="flex flex-col items-center justify-center h-full p-4">
            <div className="text-5xl mb-4">🌐</div>
            <h1 className="text-2xl font-bold mb-2">Welcome to WebProxy</h1>
            <p className="text-gray-600 text-center max-w-md mb-8">
              Enter a URL in the field above to browse that website through our proxy.
            </p>
            <div className="flex flex-col gap-2">
              <h2 className="text-lg font-medium">Quick Links:</h2>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                {[
                  'google.com',
                  'youtube.com',
                  'github.com',
                  'wikipedia.org',
                  'reddit.com',
                  'coolmathgames.com'
                ].map((site) => (
                  <button
                    key={site}
                    onClick={() => {
                      setInputUrl(site);
                      const url = validateAndFormatUrl(site);
                      if (url) {
                        setCurrentUrl(url);
                        setHasContent(true);
                        
                        const newHistory = history.slice(0, historyIndex + 1);
                        newHistory.push(url);
                        setHistory(newHistory);
                        setHistoryIndex(newHistory.length - 1);
                      }
                    }}
                    className="py-2 px-3 bg-gray-100 hover:bg-gray-200 rounded text-left"
                  >
                    {site}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
      </main>
      
      <footer className="bg-white shadow-sm-top py-2 px-4 text-center text-gray-500 text-sm">
        WebProxy - Browse the web privately and securely
      </footer>
    </div>
  );
}

export default App;