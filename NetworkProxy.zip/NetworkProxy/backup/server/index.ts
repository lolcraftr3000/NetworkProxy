import express, { Express, Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";
import { setupProxy } from "./proxyService";

async function main() {
  const app: Express = express();
  
  // Set up proxy service
  setupProxy(app);
  
  // Register routes
  const server = await registerRoutes(app);
  
  // Development mode with Vite, or static serving
  if (process.env.NODE_ENV === "development") {
    log("Running in development mode with Vite");
    await setupVite(app, server);
  } else {
    log("Running in production mode");
    serveStatic(app);
  }
  
  // Global error handler
  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    console.error("Server error:", err);
    res.status(500).json({
      message: "An unexpected error occurred on the server",
    });
  });
  
  // Close the server gracefully on SIGINT/SIGTERM
  const signals = ["SIGINT", "SIGTERM"];
  for (const signal of signals) {
    process.on(signal, () => {
      log(`Received ${signal}, shutting down...`);
      server.close(() => {
        log("Server closed");
        process.exit(0);
      });
    });
  }
}

main().catch((err) => {
  console.error("Failed to start server:", err);
  process.exit(1);
});